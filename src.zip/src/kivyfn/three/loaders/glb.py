# kivyfn/three/loaders/glb.py

from __future__ import annotations

import base64
import io
import os
import xxhash
from pathlib import Path
from typing import Any, ClassVar, cast

import numpy as np
from kivy.core.image import Image
from kivy.graphics.texture import Texture
from pygltflib import GLTF2

from kivyfn.three.loaders.asset import AssetObject
from kivyfn.three.loaders.asset import SceneAsset
from kivyfn.three.math.matrix import Matrix3
from kivyfn.three.math.matrix import Matrix4
from kivyfn.three.math.quaternion import Quaternion
from kivyfn.three.math.transform import Transform
from kivyfn.three.math.vector import Vector3
from kivyfn.three.objects.geometry import Geometry
from kivyfn.three.objects.material import Material


class GlbLoader:

    _DTYPE_MAP: ClassVar[dict[int, Any]] = {
        5120: np.int8,
        5121: np.uint8,
        5122: np.int16,
        5123: np.uint16,
        5125: np.uint32,
        5126: np.float32,
    }

    _COMPONENT_COUNT_MAP: ClassVar[dict[str, int]] = {
        "SCALAR": 1,
        "VEC2": 2,
        "VEC3": 3,
        "VEC4": 4,
        "MAT2": 4,
        "MAT3": 9,
        "MAT4": 16,
    }

    _SAMPLER_MIN_FILTER_MAP: ClassVar[dict[int, str]] = {
        9728: "nearest",
        9729: "linear",
        9984: "nearest_mipmap_nearest",
        9985: "linear_mipmap_nearest",
        9986: "nearest_mipmap_linear",
        9987: "linear_mipmap_linear",
    }

    _SAMPLER_MAG_FILTER_MAP: ClassVar[dict[int, str]] = {
        9728: "nearest",
        9729: "linear",
    }

    _SAMPLER_WRAP_MAP: ClassVar[dict[int, str]] = {
        33071: "clamp_to_edge",
        33648: "mirrored_repeat",
        10497: "repeat",
    }

    _MIME_EXTENSION_MAP: ClassVar[dict[str, str]] = {
        "image/jpeg": "jpg",
        "image/png": "png",
        "image/webp": "webp",
    }

    def __init__(
        self,
        flip_v: bool = False,
        flip_winding: bool = False,
    ):
        self.flip_v = flip_v
        self.flip_winding = flip_winding

        self.scene: SceneAsset = SceneAsset()
        self._gltf: Any = None
        self._buffer_bytes: bytes | None = None
        self._base_path: Path | None = None

        self._texture_cache: dict[int, Texture] = {}
        self._image_bytes_cache: dict[int, tuple[bytes, str]] = {}
        self._image_texture_cache: dict[
            tuple[
                str,
                int | None,
                int | None,
                int | None,
                int | None,
            ],
            Texture,
        ] = {}

    def load(
        self,
        filename: str | Path,
    ) -> SceneAsset:
        path = Path(filename)

        self.scene = SceneAsset()
        self._gltf = GLTF2().load_binary(str(path))
        self._buffer_bytes = self._load_buffer_bytes(path)
        self._base_path = path.parent

        self._texture_cache.clear()
        self._image_bytes_cache.clear()
        self._image_texture_cache.clear()

        for root_index in self._get_scene_root_indices():
            root_asset = self._load_node(root_index)
            self.scene.tree.append(root_asset)

        return self.scene

    # =================================== #
    # Scene / Node Tree
    # =================================== #
    def _get_scene_root_indices(self) -> list[int]:
        if self._gltf.scenes and self._gltf.scene is not None:
            scene = self._gltf.scenes[self._gltf.scene]
            return list(scene.nodes or [])

        nodes = self._gltf.nodes or []
        child_indices: set[int] = set()

        for node in nodes:
            child_indices.update(node.children or [])

        return [
            index
            for index in range(len(nodes))
            if index not in child_indices
        ]

    def _load_node(
        self,
        node_index: int,
    ) -> AssetObject:
        node = self._gltf.nodes[node_index]

        node_name = self._get_node_name(
            node_index=node_index,
            node=node,
        )
        # TODO: add logger.debug when loading nodes

        primitives = self._get_node_primitives(node)
        local_transform = self._get_node_local_transform(node)

        if len(primitives) == 1:
            primitive = primitives[0]
            geometry = self._process_primitive(primitive)

            if geometry is not None:
                geometry.name = node_name

            asset = AssetObject(
                name=node_name,
                geometry=geometry,
                transform=local_transform,
                material=(
                    self._process_material(
                        primitive=primitive,
                        fallback_name=node_name,
                    )
                    if geometry is not None
                    else None
                ),
            )

            self._register_asset(asset)

        else:
            asset = AssetObject(
                name=node_name,
                geometry=None,
                transform=local_transform,
                material=None,
            )

            self._register_asset(asset)

            for primitive_index, primitive in enumerate(primitives):
                geometry = self._process_primitive(primitive)

                if geometry is None:
                    continue

                primitive_name = self._make_unique_name(
                    f"{node_name}.{primitive_index:03d}"
                )

                geometry.name = primitive_name

                primitive_asset = AssetObject(
                    name=primitive_name,
                    geometry=geometry,
                    transform=Transform(),
                    material=self._process_material(
                        primitive=primitive,
                        fallback_name=primitive_name,
                    ),
                )

                self._register_asset(primitive_asset)
                asset.children.append(primitive_asset)

        for child_index in node.children or []:
            child_asset = self._load_node(child_index)
            asset.children.append(child_asset)

        return asset

    def _get_node_name(
        self,
        node_index: int,
        node: Any,
    ) -> str:
        mesh_name = None

        if node.mesh is not None:
            mesh = self._gltf.meshes[node.mesh]
            mesh_name = mesh.name

        name = (
            node.name
            or mesh_name
            or f"node_{node_index}"
        )

        return self._make_unique_name(name)

    def _make_unique_name(
        self,
        name: str,
    ) -> str:
        if name not in self.scene.objects:
            return name

        counter = 1

        while True:
            candidate = f"{name}.{counter:03d}"

            if candidate not in self.scene.objects:
                return candidate

            counter += 1

    def _register_asset(
        self,
        asset: AssetObject,
    ) -> None:
        self.scene.objects[asset.name] = asset

    def _get_node_primitives(
        self,
        node: Any,
    ) -> list[Any]:
        if node.mesh is None:
            return []

        mesh = self._gltf.meshes[node.mesh]
        return list(mesh.primitives or [])

    # =================================== #
    # Node Transforms
    # =================================== #
    def _get_node_local_transform(
        self,
        node: Any,
    ) -> Transform:
        if getattr(node, "matrix", None):
            matrix = Matrix4(
                np.array(
                    node.matrix,
                    dtype=np.float32,
                ).reshape((4, 4))
            )

            return self._transform_from_matrix4(matrix)

        translation_data = getattr(node, "translation", None)
        rotation_data = getattr(node, "rotation", None)
        scale_data = getattr(node, "scale", None)

        translation = (
            Vector3(
                float(translation_data[0]),
                float(translation_data[1]),
                float(translation_data[2]),
            )
            if translation_data is not None
            else Vector3(0.0, 0.0, 0.0)
        )

        rotation = (
            Quaternion(
                float(rotation_data[0]),
                float(rotation_data[1]),
                float(rotation_data[2]),
                float(rotation_data[3]),
            )
            if rotation_data is not None
            else Quaternion.identity()
        )

        scale = (
            Vector3(
                float(scale_data[0]),
                float(scale_data[1]),
                float(scale_data[2]),
            )
            if scale_data is not None
            else Vector3(1.0, 1.0, 1.0)
        )

        return Transform(
            translation=translation,
            rotation=rotation,
            scale=scale,
        )

    def _transform_from_matrix4(
        self,
        matrix: Matrix4,
    ) -> Transform:
        values = matrix.values

        translation = Vector3(
            float(values[0, 3]),
            float(values[1, 3]),
            float(values[2, 3]),
        )

        scale = Vector3(
            float(np.linalg.norm(values[:3, 0])),
            float(np.linalg.norm(values[:3, 1])),
            float(np.linalg.norm(values[:3, 2])),
        )

        rotation_values = values[:3, :3].copy()

        if scale.x != 0.0:
            rotation_values[:, 0] /= scale.x

        if scale.y != 0.0:
            rotation_values[:, 1] /= scale.y

        if scale.z != 0.0:
            rotation_values[:, 2] /= scale.z

        rotation = Quaternion.from_matrix3(
            Matrix3(
                rotation_values.astype(
                    np.float32,
                    copy=False,
                )
            )
        )

        return Transform(
            translation=translation,
            rotation=rotation,
            scale=scale,
        )

    # =================================== #
    # Materials
    # =================================== #
    def _process_material(
        self,
        primitive: Any,
        fallback_name: str,
    ) -> Material:
        material_index = getattr(
            primitive,
            "material",
            None,
        )

        if (
            material_index is None
            or not self._gltf.materials
            or material_index < 0
            or material_index >= len(self._gltf.materials)
        ):
            return Material(
                name=fallback_name,
            )

        gltf_material = self._gltf.materials[material_index]

        material = Material(
            name=(
                gltf_material.name
                or fallback_name
            ),
        )

        pbr = getattr(
            gltf_material,
            "pbrMetallicRoughness",
            None,
        )

        if pbr is not None:
            self._apply_pbr_material(
                material=material,
                pbr=pbr,
            )

        emissive_factor = getattr(
            gltf_material,
            "emissiveFactor",
            None,
        )

        if emissive_factor is not None:
            material.emissive_factor = [
                float(emissive_factor[0]),
                float(emissive_factor[1]),
                float(emissive_factor[2]),
            ]

        normal_texture = self._load_texture_from_info(
            getattr(
                gltf_material,
                "normalTexture",
                None,
            )
        )

        if normal_texture is not None:
            material.normal_texture = normal_texture

        emissive_texture = self._load_texture_from_info(
            getattr(
                gltf_material,
                "emissiveTexture",
                None,
            )
        )

        if emissive_texture is not None:
            material.emissive_texture = emissive_texture

        occlusion_texture = self._load_texture_from_info(
            getattr(
                gltf_material,
                "occlusionTexture",
                None,
            )
        )

        if occlusion_texture is not None:
            material.occlusion_texture = occlusion_texture

        material.sync_uniforms()

        return material

    def _apply_pbr_material(
        self,
        material: Material,
        pbr: Any,
    ) -> None:
        base_color = getattr(
            pbr,
            "baseColorFactor",
            None,
        )

        metallic_factor = getattr(
            pbr,
            "metallicFactor",
            None,
        )

        roughness_factor = getattr(
            pbr,
            "roughnessFactor",
            None,
        )

        if base_color is not None:
            material.base_color = [
                float(base_color[0]),
                float(base_color[1]),
                float(base_color[2]),
                float(base_color[3]),
            ]

        if metallic_factor is not None:
            material.metallic_factor = float(
                metallic_factor
            )

        if roughness_factor is not None:
            material.roughness_factor = float(
                roughness_factor
            )

        base_texture = self._load_texture_from_info(
            getattr(
                pbr,
                "baseColorTexture",
                None,
            )
        )

        if base_texture is not None:
            material.base_texture = base_texture

        metallic_roughness_texture = self._load_texture_from_info(
            getattr(
                pbr,
                "metallicRoughnessTexture",
                None,
            )
        )

        if metallic_roughness_texture is not None:
            material.metallic_roughness_texture = (
                metallic_roughness_texture
            )

    # =================================== #
    # Textures / Images
    # =================================== #
    def _load_texture_from_info(
        self,
        texture_info: Any,
    ) -> Texture | None:
        if texture_info is None:
            return None

        texture_index = getattr(
            texture_info,
            "index",
            None,
        )

        if texture_index is None:
            return None

        return self._load_texture(texture_index)

    def _load_texture(
        self,
        texture_index: int,
    ) -> Texture | None:
        if (
            not self._gltf.textures
            or texture_index < 0
            or texture_index >= len(self._gltf.textures)
        ):
            return None

        cached_texture = self._texture_cache.get(texture_index)

        if cached_texture is not None:
            return cached_texture

        gltf_texture = self._gltf.textures[texture_index]

        image_index = getattr(
            gltf_texture,
            "source",
            None,
        )

        if image_index is None:
            return None

        sampler_key = self._get_sampler_cache_key(
            gltf_texture
        )

        texture = self._load_image_texture(
            image_index=image_index,
            sampler_key=sampler_key,
        )

        if texture is None:
            return None

        self._apply_sampler(
            texture=texture,
            gltf_texture=gltf_texture,
        )

        self._texture_cache[texture_index] = texture

        return texture

    def _load_image_texture(
        self,
        image_index: int,
        sampler_key: tuple[
            int | None,
            int | None,
            int | None,
            int | None,
        ],
    ) -> Texture | None:
        image_data = self._load_image_data(image_index)

        if image_data is None:
            return None

        image_bytes, extension = image_data

        image_hash = xxhash.xxh3_64_hexdigest(
            image_bytes
        )

        key = (
            image_hash,
            sampler_key[0],
            sampler_key[1],
            sampler_key[2],
            sampler_key[3],
        )

        cached_texture = self._image_texture_cache.get(key)

        if cached_texture is not None:
            return cached_texture

        image = Image(
            io.BytesIO(image_bytes),
            ext=extension,
            mipmap=True,
            nocache=True,
        )

        texture = image.texture
        if texture is None:
            return None

        texture.min_filter = "linear_mipmap_linear"
        texture.mag_filter = "linear"
        texture.wrap = "repeat"

        self._image_texture_cache[key] = texture

        return texture

    def _load_image_data(
        self,
        image_index: int,
    ) -> tuple[bytes, str] | None:
        cached_data = self._image_bytes_cache.get(
            image_index
        )

        if cached_data is not None:
            return cached_data

        if (
            not self._gltf.images
            or image_index < 0
            or image_index >= len(self._gltf.images)
        ):
            return None

        image = self._gltf.images[image_index]

        image_bytes, extension = self._load_image_bytes(
            image=image,
        )

        if image_bytes is None:
            return None

        image_data = (
            image_bytes,
            extension,
        )

        self._image_bytes_cache[image_index] = image_data

        return image_data

    def _get_sampler_cache_key(
        self,
        gltf_texture: Any,
    ) -> tuple[
        int | None,
        int | None,
        int | None,
        int | None,
    ]:
        sampler_index = getattr(
            gltf_texture,
            "sampler",
            None,
        )

        if (
            sampler_index is None
            or not self._gltf.samplers
            or sampler_index < 0
            or sampler_index >= len(self._gltf.samplers)
        ):
            return (
                None,
                None,
                None,
                None,
            )

        sampler = self._gltf.samplers[sampler_index]

        return (
            getattr(
                sampler,
                "minFilter",
                None,
            ),
            getattr(
                sampler,
                "magFilter",
                None,
            ),
            getattr(
                sampler,
                "wrapS",
                None,
            ),
            getattr(
                sampler,
                "wrapT",
                None,
            ),
        )

    def _apply_sampler(
        self,
        texture: Texture,
        gltf_texture: Any,
    ) -> None:
        sampler_index = getattr(
            gltf_texture,
            "sampler",
            None,
        )

        if (
            sampler_index is None
            or not self._gltf.samplers
            or sampler_index < 0
            or sampler_index >= len(self._gltf.samplers)
        ):
            return

        sampler = self._gltf.samplers[sampler_index]

        min_filter = self._sampler_min_filter_to_kivy(
            getattr(
                sampler,
                "minFilter",
                None,
            )
        )

        mag_filter = self._sampler_mag_filter_to_kivy(
            getattr(
                sampler,
                "magFilter",
                None,
            )
        )

        wrap_s = self._sampler_wrap_to_kivy(
            getattr(
                sampler,
                "wrapS",
                None,
            )
        )

        wrap_t = self._sampler_wrap_to_kivy(
            getattr(
                sampler,
                "wrapT",
                None,
            )
        )

        texture_options = cast(Any, texture)

        if min_filter is not None:
            texture_options.min_filter = min_filter

        if mag_filter is not None:
            texture_options.mag_filter = mag_filter

        if wrap_s is not None and wrap_t is not None:
            if wrap_s == wrap_t:
                texture_options.wrap = wrap_s

        elif wrap_s is not None:
            texture_options.wrap = wrap_s

        elif wrap_t is not None:
            texture_options.wrap = wrap_t

    def _sampler_min_filter_to_kivy(
        self,
        value: int | None,
    ) -> str | None:
        if value is None:
            return None

        return self._SAMPLER_MIN_FILTER_MAP.get(value)

    def _sampler_mag_filter_to_kivy(
        self,
        value: int | None,
    ) -> str | None:
        if value is None:
            return None

        return self._SAMPLER_MAG_FILTER_MAP.get(value)

    def _sampler_wrap_to_kivy(
        self,
        value: int | None,
    ) -> str | None:
        if value is None:
            return None

        return self._SAMPLER_WRAP_MAP.get(value)

    def _load_image_bytes(
        self,
        image: Any,
    ) -> tuple[bytes | None, str]:
        uri = getattr(
            image,
            "uri",
            None,
        )

        mime_type = getattr(
            image,
            "mimeType",
            None,
        )

        buffer_view_index = getattr(
            image,
            "bufferView",
            None,
        )

        if uri:
            if uri.startswith("data:"):
                header, encoded = uri.split(",", 1)

                mime_type = (
                    header.split(";", 1)[0].replace("data:", "")
                    or mime_type
                )

                return (
                    base64.b64decode(encoded),
                    self._extension_from_mime_type(mime_type),
                )

            if self._base_path is None:
                raise RuntimeError(
                    "GLB base path was not set."
                )

            image_path = (
                Path(uri)
                if os.path.isabs(uri)
                else self._base_path / uri
            )

            return (
                image_path.read_bytes(),
                image_path.suffix.lstrip(".") or "png",
            )

        if buffer_view_index is not None:
            return (
                self._read_buffer_view_bytes(buffer_view_index),
                self._extension_from_mime_type(mime_type),
            )

        return None, self._extension_from_mime_type(mime_type)

    def _read_buffer_view_bytes(
        self,
        buffer_view_index: int,
    ) -> bytes:
        if self._buffer_bytes is None:
            raise RuntimeError(
                "GLB buffer bytes were not loaded."
            )

        view = self._gltf.bufferViews[buffer_view_index]

        byte_offset = view.byteOffset or 0
        byte_length = view.byteLength or 0

        return self._buffer_bytes[
            byte_offset : byte_offset + byte_length
        ]

    def _extension_from_mime_type(
        self,
        mime_type: str | None,
    ) -> str:
        if mime_type is None:
            return "png"

        return self._MIME_EXTENSION_MAP.get(
            mime_type,
            "png",
        )

    # =================================== #
    # Buffer Reading
    # =================================== #
    def _load_buffer_bytes(
        self,
        filename: Path,
    ) -> bytes:
        buffer_bytes = self._gltf.binary_blob()

        if buffer_bytes is not None:
            return buffer_bytes

        if not self._gltf.buffers:
            raise ValueError("No buffer found in GLB file.")

        uri = self._gltf.buffers[0].uri

        if uri and uri.startswith("data:"):
            encoded = uri.split(",", 1)[1]
            return base64.b64decode(encoded)

        if uri:
            bin_path = (
                Path(uri)
                if os.path.isabs(uri)
                else filename.parent / uri
            )

            with open(bin_path, "rb") as file:
                return file.read()

        raise ValueError("No binary buffer found in GLB file.")

    def _read_accessor(
        self,
        accessor_index: int | None,
    ) -> np.ndarray | None:
        if accessor_index is None:
            return None

        if self._buffer_bytes is None:
            raise RuntimeError(
                "GLB buffer bytes were not loaded."
            )

        buffer_bytes = self._buffer_bytes
        accessor = self._gltf.accessors[accessor_index]

        if accessor.bufferView is None:
            return None

        view = self._gltf.bufferViews[accessor.bufferView]

        view_offset = view.byteOffset or 0
        accessor_offset = accessor.byteOffset or 0
        stride = view.byteStride or 0
        count = accessor.count

        dtype = self._DTYPE_MAP[accessor.componentType]
        component_count = self._COMPONENT_COUNT_MAP.get(
            accessor.type,
            1,
        )

        dtype_info = np.dtype(dtype)
        element_size = dtype_info.itemsize * component_count
        start = view_offset + accessor_offset

        if stride and stride != element_size:
            return np.ndarray(
                shape=(count, component_count),
                dtype=dtype,
                buffer=buffer_bytes,
                offset=start,
                strides=(
                    stride,
                    dtype_info.itemsize,
                ),
            )

        array = np.frombuffer(
            buffer_bytes,
            dtype=dtype,
            count=count * component_count,
            offset=start,
        )

        return array.reshape((count, component_count))

    # =================================== #
    # Geometry
    # =================================== #
    def _process_primitive(
        self,
        primitive: Any,
    ) -> Geometry | None:
        position_index = getattr(
            primitive.attributes,
            "POSITION",
            None,
        )

        if position_index is None:
            return None

        positions = self._read_accessor(position_index)

        if positions is None:
            return None

        positions = positions.astype(
            np.float32,
            copy=False,
        )

        vertex_count = positions.shape[0]

        index_index = primitive.indices

        if index_index is not None:
            indices = self._read_accessor(index_index)

            if indices is None:
                return None

            final_indices = indices.reshape(-1).astype(
                np.int64,
                copy=False,
            )

        else:
            final_indices = np.arange(
                vertex_count,
                dtype=np.int64,
            )

        normals = self._read_accessor(
            getattr(
                primitive.attributes,
                "NORMAL",
                None,
            )
        )

        if normals is None or normals.shape[1] < 3:
            normals = np.zeros_like(
                positions[:, :3],
                dtype=np.float32,
            )
        else:
            normals = normals[:, :3].astype(
                np.float32,
                copy=False,
            )

        uvs = self._read_accessor(
            getattr(
                primitive.attributes,
                "TEXCOORD_0",
                None,
            )
        )

        if uvs is None or uvs.shape[1] < 2:
            uvs = np.zeros(
                (vertex_count, 2),
                dtype=np.float32,
            )
        else:
            uvs = uvs[:, :2].astype(
                np.float32,
                copy=False,
            )

            if self.flip_v:
                uvs = uvs.copy()

        if self.flip_v:
            uvs[:, 1] = 1.0 - uvs[:, 1]

        tangents = self._read_accessor(
            getattr(
                primitive.attributes,
                "TANGENT",
                None,
            )
        )

        has_source_tangents = (
            tangents is not None
            and tangents.shape[1] >= 4
        )

        if not has_source_tangents:
            tangents = np.zeros(
                (vertex_count, 4),
                dtype=np.float32,
            )

            tangents[:, 0] = 1.0
            tangents[:, 3] = 1.0

        else:
            assert tangents is not None
            tangents = tangents[:, :4].astype(
                np.float32,
                copy=False,
            )

        if self.flip_winding and len(final_indices) % 3 == 0:
            final_indices = final_indices.reshape(-1, 3)
            final_indices[:, [1, 2]] = final_indices[:, [2, 1]]
            final_indices = final_indices.reshape(-1)

        final_indices = self._ensure_uint16_indices(final_indices)

        packed_vertices = np.column_stack(
            [
                positions[:, :3],
                normals,
                uvs,
                tangents,
            ]
        ).reshape(-1)

        return Geometry(
            vertices=packed_vertices,
            indices=final_indices,
            has_source_tangents=has_source_tangents,
        )

    def _ensure_uint16_indices(
        self,
        indices: np.ndarray,
    ) -> np.ndarray:
        if indices.size == 0:
            return indices.astype(
                np.uint16,
                copy=False,
            )

        total = int(indices.max())

        if total > 65535:
            raise OverflowError(
                "Indices exceed 65535 in a single primitive. "
                "Split the primitive before loading it."
            )

        return indices.astype(
            np.uint16,
            copy=False,
        )
