# kivyfn/three/render/renderer.py

from __future__ import annotations

from typing import Callable, TYPE_CHECKING

from kivy.graphics import Callback, Canvas
from kivy.graphics.transformation import Matrix

from kivyfn.three.render.context import RenderContext
from kivyfn.three.render.manager import RenderContextManager
from kivyfn.three.render.shader import Shader
from kivyfn.three.scene.node import Node3D

if TYPE_CHECKING:
    from kivyfn.three.lights.manager import LightManager


GLCallback = Callable[..., None]


class Renderer:
    def __init__(
        self,
        canvas: Canvas,
    ):
        self.canvas = canvas
        self.contexts = RenderContextManager()

        self._modelview_mat: Matrix | None = None
        self._projection_mat: Matrix | None = None

    def __repr__(self) -> str:
        return (
            f"Renderer("
            f"contexts={len(self.contexts)}, "
            f")"
        )

    # =================================== #
    # Light
    # =================================== #
    def sync_lights(self, manager: LightManager) -> None:
        lights = list(manager.values())

        if not lights:
            self.contexts.set_uniform_by_tag("lit", "point_light_enabled", 0.0)
            return

        light = lights[0]

        self.contexts.set_uniform_by_tag("lit", "point_light_enabled", 1.0)
        self.contexts.set_uniform_by_tag("lit", "point_light_color", list(light.color))
        self.contexts.set_uniform_by_tag("lit", "point_light_intensity", float(light.intensity))

        radius = getattr(light, "radius", None)
        if radius is not None:
            self.contexts.set_uniform_by_tag("lit", "point_light_radius", float(radius))

        world_position = light.world_matrix.transform_point(0.0, 0.0, 0.0)

        if self._modelview_mat is not None:
            position = self._modelview_mat.transform_point(
                world_position[0],
                world_position[1],
                world_position[2],
            )
        else:
            position = world_position

        self.contexts.set_uniform_by_tag(
            "lit",
            "point_light_position",
            list(position),
        )

    # =================================== #
    # Contexts
    # =================================== #
    def create_context(
        self,
        name: str,
        shader: Shader,
        hot_reload: bool,
        tags: set[str] | None = None,
    ) -> RenderContext:
        context = RenderContext(
            name=name,
            shader=shader,
            hot_reload=hot_reload,
        )

        self.contexts.add(
            name=name,
            context=context,
            tags=tags,
        )

        self.canvas.add(context.ctx)
        self.sync_context_view(context)

        return context

    def remove_context(
        self,
        name: str,
    ) -> None:
        context = self.contexts.remove(name)

        if context is None:
            return

        context.destroy()

        try:
            self.canvas.remove(context.ctx)
        except ValueError:
            pass


    def clear_contexts(
        self,
    ) -> None:
        for name in self.contexts.names():
            self.remove_context(name)


    # =================================== #
    # Build
    # =================================== #
    def clear(self) -> None:
        for ctx in self.contexts.values():
            ctx.clear()

    def remove(self, node: Node3D) -> None:
        self.detach(node)

    def add(
        self,
        node: Node3D,
        context: str,
        setup_gl_context: GLCallback,
        reset_gl_context: GLCallback,
    ) -> None:
        ctx = self.contexts.get(context)

        with ctx:
            Callback(setup_gl_context)
            self.attach(node, ctx)
            Callback(reset_gl_context)

    def attach(
        self,
        node: Node3D,
        ctx: RenderContext,
    ) -> None:
        for child in node.walk_tree():
            child.attach(ctx)

    def detach(
        self,
        node: Node3D,
    ) -> None:
        for child in node.walk_tree():
            child.detach()

    # =================================== #
    # View
    # =================================== #
    def update_view(
        self,
        camera,
        aspect: float,
    ) -> None:
        self._projection_mat = camera.get_projection_matrix(aspect)
        self._modelview_mat = camera.get_view_matrix()

        for ctx in self.contexts.values():
            self.sync_context_view(ctx)

    def sync_context_view(
        self,
        ctx: RenderContext,
    ) -> None:
        if self._projection_mat is not None:
            ctx["projection_mat"] = self._projection_mat

        if self._modelview_mat is not None:
            ctx["modelview_mat"] = self._modelview_mat

    @property
    def modelview_mat(
        self,
    ) -> Matrix:
        assert self._modelview_mat is not None
        return self._modelview_mat

    @property
    def projection_mat(
        self,
    ) -> Matrix:
        assert self._projection_mat is not None
        return self._projection_mat
